package com.example.weather
import android.content.Context
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.weather.MyAdapter
//import com.example.howweather.network.API_KEY



//import com.example.weather.Model.WeatherModel
import com.example.weather.Repo


import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val currentDate by lazy { SimpleDateFormat("yyyyMMdd", Locale.KOREA).format(Date()) }
    val myViewModel = MyViewModel(Repo(this))
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)


        val connectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val nw = connectivityManager.activeNetwork // 현재 활성화된 네트워크
        val actNw = connectivityManager.getNetworkCapabilities(nw)

        val isConnected = actNw!!.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)

        if (isConnected) {
            Snackbar.make(findViewById(R.id.main), "인터넷 연결", Snackbar.LENGTH_SHORT)
        }

//        findViewById<Button>(R.id.buttonQuery).setOnClickListener {
//            //downloadImage()
//            refreshRetrofit(findViewById<EditText>(R.id.editUsername).text.toString())
//
//        }
        val adapter = MyAdapter(myViewModel)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)

        myViewModel.weatherList.observe(this) {
            println(it.size)
            Log.d("observer","${it.size}")
            when(myViewModel.itemsEvent){
                ItemEvent.ADD->adapter.notifyItemInserted(myViewModel.itemEventPos)
                ItemEvent.DELETE->adapter.notifyItemRemoved(myViewModel.itemEventPos)
                ItemEvent.UPDATE-> println("nothing update")
                ItemEvent.CLEAR->adapter.notifyDataSetChanged()
            }


        }
        myViewModel.weatherData.observe(this) {
            println(it)
            Log.d("observer","${it}")
            when(myViewModel.itemsEvent){
                ItemEvent.ADD->adapter.notifyItemInserted(myViewModel.itemEventPos)
                ItemEvent.DELETE->adapter.notifyItemRemoved(myViewModel.itemEventPos)
                ItemEvent.UPDATE-> println("nothing update")
                ItemEvent.CLEAR->adapter.notifyDataSetChanged()
            }


        }



        myViewModel.getWeather(currentDate)

        Log.d("observer","after observer")

    }






    fun formatTimeString(): String? {
        val currentDate = java.text.SimpleDateFormat("yyyy.MM.dd", java.util.Locale.getDefault())
            .format(java.util.Date())
        return currentDate
    }


}


