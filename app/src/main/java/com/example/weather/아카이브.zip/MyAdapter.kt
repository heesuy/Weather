package com.example.weather

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.weather.R

class MyAdapter(val viewModel: MyViewModel) : RecyclerView.Adapter<MyAdapter.MyViewHolder>() {
    inner class MyViewHolder(val view : View) : RecyclerView.ViewHolder(view){
            fun setContents(position: Int){
               val data = viewModel.getData()
                val data1 = viewModel.weatherList
                val data2 = viewModel.weatherData

                if( data1.value != null){
                    print(data1.value?.size)
            with(data1.value!!.get(position)){
                val str = StringBuilder().also{


                        it.append("온도는 : ")
                        it.append(this.temp)




                    //it.append("")
                    }
                .toString()
                view.findViewById<TextView>(R.id.textView2).text = str

            }}

            }

    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyAdapter.MyViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.item_layout,parent,false)
        val viewHolder = MyViewHolder(view)
        return viewHolder
    }

    override fun onBindViewHolder(holder: MyAdapter.MyViewHolder, position: Int) {
        holder.setContents(position)

    }

    override fun getItemCount(): Int {
    println("getItemCOunt ${viewModel.getData().value}")
        println("getItemCOunt ${viewModel.getData().value?.size?:0}")

       return viewModel.data2.size?:0
    }
}