package com.example.weather

import WeatherResponse
import android.content.Context
import com.example.weather.RestApi
import android.icu.text.SimpleDateFormat
import android.os.Environment
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore

import com.example.weather.Data.cityList
//import com.example.weather.Model.WeatherModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.util.Date
import java.util.Locale

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")
class MyPrefKey {
    companion object {
        val name_key = stringPreferencesKey("name")
        val student_id_key = stringPreferencesKey("student_id")

    }
}
class Repo(private val context: Context) {
//    private val fileInternal = File(context.filesDir, "appfile1.txt")
//    private val fileExternal =
//        if (isExternalStorageMounted)
//            File(context.getExternalFilesDir(null), "appfile2.txt")
//        else
//            fileInternal
//
//    var valueInternal: String = readValue(fileInternal) // initialized by readValue
//        set(v) {
//            field = v
//            writeValue(fileInternal, v) // write value whenever update the value
//        }
//
//    var valueExternal: String = readValue(fileExternal) // initialized by readValue
//        set(v) {
//            field = v
//            writeValue(fileExternal, v)  // write value whenever update the value
//        }
//
//    val myPref : Flow<Preferences> = context.dataStore.data
//    suspend fun setPref(key: Preferences.Key<String>, value: String) {
//        context.dataStore.edit {
//            it[key] = value
//        }
//    }
//
//
//
//    private fun readValue(file: File) : String {
//        return try {
//            println("$file")
//            // Internal Storage - /data/user/0/com.example.fileexample/files/appfile.txt
//            // External Storage - /storage/emulated/0/Android/data/com.example.fileexample/files/appfile.txt
//            file.readText(Charsets.UTF_8)
//        } catch (e: Exception) {
//            ""
//        }
//    }
//
//    private fun writeValue(file: File, value: String) {
//        file.writeText(value, Charsets.UTF_8)
//    }
//
//    private val isExternalStorageMounted: Boolean
//        get() {
//            val state = Environment.getExternalStorageState()
//            return state == Environment.MEDIA_MOUNTED
//        }


    suspend fun getWeather(): WeatherResponse {
        val baseURL = "https://api.openweathermap.org/"
        val api: RestApi = with(Retrofit.Builder()) {
            baseUrl(baseURL)
            addConverterFactory(GsonConverterFactory.create())
            build()
        }.create(RestApi::class.java)

        return withContext(Dispatchers.IO) {
           // val city = cityList.find { it.name == cityName } ?: cityList.first()
            api.getWeather()
        }
    }




//    override fun onPostExecute(result: String?) {
//        super.onPostExecute(result)
//        try{
//            val jsonObj= JSONObject(result)
//            val main=jsonObj.getJSONObject("main")
//            val sys=jsonObj.getJSONObject("sys")
//            val wind=jsonObj.getJSONObject("wind")
//            val weather=jsonObj.getJSONArray("weather").getJSONObject(0)
//            val updateAt:Long=jsonObj.getLong("dt")
//            val updatedAtText="Update at: "+ SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale.KOREAN).format(
//                Date(updateAt*1000)
//            )
//            val temp=main.getString("temp")+"℃"
//            val tempMin = "최저 온도: "+main.getString("temp_min")+"℃"
//            val tempMax = "최고 온도: "+main.getString("temp_max")+"℃"
//            val pressure = main.getString("pressure")+"hPa"
//            val humidity = main.getString("humidity")
//            val sunrise:Long = sys.getLong("sunrise")
//            val sunset:Long = sys.getLong("sunset")
//            val windSpeed = wind.getString("speed")+"m/s"
//            val weatherDescription= weather.getString("description")
//            val address=jsonObj.getString("name")+", "+sys.getString("country")
//
//
//        }
}