package com.example.weather

import WeatherResponse
//import com.example.weather.Model.WeatherModel
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface RestApi {



    @GET("data/2.5/weather")
    suspend fun getWeather(
        @Query("q") city: String = "Seoul",
        @Query("appid") apiKey: String = "44ee568572566e2e694290868d9d742c",
        @Query("units") units: String = "metric"
    ): WeatherResponse

    @GET("users/{username}/repos")
    fun listReposCall(@Path("username") user: String): Call<ArrayList<Repo>> // 콜백 사용할거면 코루틴 스코프 필요 없어!
    @GET("wp-content/uploads/2019/03/google_logo_download_thumbnail.png")
    suspend fun getImage(): ResponseBody
}