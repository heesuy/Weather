package com.example.weather

import WeatherData
import android.content.ContentValues.TAG
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
//import com.example.weather.Data.WeatherData
import com.example.weather.Repo
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException


enum class ItemEvent {
    ADD, UPDATE, DELETE, CLEAR
}

class MyViewModel(private val repository: Repo) : ViewModel() {

    private val data = MutableLiveData<ArrayList<Repo>>()
    val data2 = ArrayList<Repo>()
    var itemsEvent = ItemEvent.ADD
    var itemEventPos = -1
    private val _weatherData = MutableLiveData<WeatherData>()
    val weatherData get() = _weatherData

    private val _weatherList = MutableLiveData<List<WeatherData>>()
    val weatherList get() = _weatherList

    fun addItem(repo: Repo) {
        itemsEvent = ItemEvent.ADD
        itemEventPos = data2.size
        data2.add(repo)
        data.value = data2
    }

    fun getData() = data

    fun deleteItem(pos: Int) {
        itemsEvent = ItemEvent.DELETE
        itemEventPos = pos
        data2.removeAt(pos)
        data.value = data2
    }

    fun deleteAllItem() {
        itemsEvent = ItemEvent.CLEAR
        itemEventPos = -1
        data2.clear()
        data.value = data2
    }

    fun getWeather(date: String, city: String = "서울특별시") {
        viewModelScope.launch {
            runCatching {
                Log.d("getWeather", "getWeather start")
                fetchWeatherData()
            }.onSuccess { weatherResponse ->
                _weatherData.value = weatherResponse
                Log.d("getWeather", "getWeather Success")
            }.onFailure { e ->
                handleException(e)
                Log.d("getWeather", "getWeather failure")
            }
        }
    }


    private fun handleException(e: Throwable) {
        Log.d("getWeather", "$e.message")
        print("getWeather fail ${e.message}")
        when (e) {
            is HttpException -> {
                val errorJsonString = e.response()?.errorBody()?.string()
                Log.d("getWeather", "HTTP error: $errorJsonString")
            }

            is IOException -> Log.e("getWeather", "Network error: $e")
            else -> Log.d("getWeather", "Unexpected error: $e")
        }
}

     suspend fun fetchWeatherData(): WeatherData {
        val apiKey = "YOUR_API_KEY"
        val weatherData =repository.getWeather()

        val feelsLike = weatherData.main.feelsLike - 273.0
        val temp = weatherData.main.temp - 273.0
        val tempMin = weatherData.main.tempMin - 273.0
        val tempMax = weatherData.main.tempMax - 273.0
        val pressure = weatherData.main.pressure
        val humidity = weatherData.main.humidity
        val windSpeed = weatherData.wind.speed
        val icon = weatherData.weather[0].icon

        // Assuming you will handle time and skyStatus correctly
        val time = "현재 시각"
        val skyStatus = "맑음" // 또는 다른 값을 매핑
        val rainStatus = "없음" // PTY 값을 매핑
        val rainPercent = "0" // POP 값을 매핑
        val rainAmount = "0mm" // PCP 값을 매핑
        val tempStr = temp.toString()

        return WeatherData(
            time = time,
            skyStatus = skyStatus,
            rainStatus = rainStatus,
            rainPercent = rainPercent,
            rainAmount = rainAmount,
            temp = tempStr
        )
    }

}