import com.google.gson.annotations.SerializedName

data class WeatherResponse(
    @SerializedName("weather") val weather: List<Weather>,
    @SerializedName("main") val main: Main,
    @SerializedName("wind") val wind: Wind
)

data class Weather(
    @SerializedName("icon") val icon: String
)

data class Main(
    @SerializedName("feels_like") val feelsLike: Double,
    @SerializedName("temp") val temp: Double,
    @SerializedName("temp_min") val tempMin: Double,
    @SerializedName("temp_max") val tempMax: Double,
    @SerializedName("pressure") val pressure: Double,
    @SerializedName("humidity") val humidity: Double
)

data class Wind(
    @SerializedName("speed") val speed: Double
)
data class WeatherData(
    val time: String,
    val skyStatus: String,
    val rainStatus: String,
    val rainPercent: String,
    val rainAmount: String,
    val temp: String
)
